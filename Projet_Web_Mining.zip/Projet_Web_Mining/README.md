# Projet-web-mining

Instructions : 

1) Télécharger le dossier contenant le fichier "MSLMM2153_group_3.jpynb" et le document "Organisations.xlsx"

2) Run chaque cellule du code présent dans le fichier "MSLMM2153_group_3" dans l'ordre. Le code devrait tourner sans rencontrer de problème.